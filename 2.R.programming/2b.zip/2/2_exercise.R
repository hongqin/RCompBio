
x = rnorm(10);
#write a loop to print out every element of x
for ? in ? {
  print(?)
}
  